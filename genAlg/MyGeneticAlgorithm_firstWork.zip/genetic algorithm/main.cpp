//#include "individual.cpp"
//#include "population.cpp"
#include "genalg.h"

//#include "individual.cpp"
int main(){
	std::cout<<"It compiled and runned"<<std::endl;
	std::vector<float> v1;
	v1.push_back(2);
	v1.push_back(1);
	v1.push_back(-4);
	individual ind1(v1);
	std::cout<<ind1.getObjectiveFunction()<<std::endl;
}