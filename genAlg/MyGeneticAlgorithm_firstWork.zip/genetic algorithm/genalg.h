#ifndef GENALG_H_
#define GENALG_H_

#include <iostream>
#include <vector>
#include <algorithm>
#include <random>
//#include "sexEnum.h"
#include "individual.h"
#include "population.h"
#endif /*GENALG_H_*/
