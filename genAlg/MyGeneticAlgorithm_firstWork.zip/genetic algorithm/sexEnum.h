#ifndef _SEX_ENUM_H_
#define _SEX_ENUM_H_

enum sexEnum{
	MALE,
	FEMALE
};
#endif