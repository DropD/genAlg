//#include "individual.cpp"
//#include "genalg.h"
//class individual;
#include <vector>
#include <iostream>
#include "population.h"

//#include "individual.h"
//class individual;

population::population(std::vector<individual> indivss){
	this->npop = indivss.size();
	this->ndim = indivss[1].getFeatureVector().size();
	for(unsigned int i=0;i<this -> npop;i++)
		(this -> indivs).push_back(indivss[i]);
	
}

population::population(int npop){
	//initialize npop individuals randomly
}

std::vector<float> population::getObjectiveFunctions(){
	std::vector<float> vec;
	std::vector<float> currIndivVec(this->ndim);
	individual currIndiv(currIndivVec);
	for(unsigned int i=0;i< this -> npop;i++){
		currIndiv = indivs[i];
		vec.push_back(currIndiv.getObjectiveFunction());
	}
	return vec;
}